// Popup script for AdBlock Pro with License Management

const STORAGE_KEY = 'adblock_license';
const API_URL = 'https://ablockyoutube.vercel.app/api/validate-license';
const ACTIVATIONS_API_URL = 'https://ablockyoutube.vercel.app/api/license-activations';
const DEACTIVATE_API_URL = 'https://ablockyoutube.vercel.app/api/deactivate-device';

// DOM Elements
const licenseStatus = document.getElementById('licenseStatus');
const statusIcon = document.getElementById('statusIcon');
const statusText = document.getElementById('statusText');
const statusBadge = document.getElementById('statusBadge');
const ytStatus = document.getElementById('ytStatus');
const infoText = document.getElementById('infoText');
const licenseKeyInput = document.getElementById('licenseKeyInput');
const submitLicenseBtn = document.getElementById('submitLicenseBtn');
const licenseMessage = document.getElementById('licenseMessage');
const licenseInputSection = document.getElementById('licenseInputSection');
const devicesSection = document.getElementById('devicesSection');
const devicesList = document.getElementById('devicesList');
const deviceCountText = document.getElementById('deviceCountText');

// Update UI based on license status
async function updateUI() {
  try {
    const status = await new Promise((resolve) => {
      let resolved = false;
      
      chrome.runtime.sendMessage({ action: 'checkLicense' }, (response) => {
        if (resolved) return;
        resolved = true;
        
        if (chrome.runtime.lastError) {
          console.error('Message error:', chrome.runtime.lastError);
          resolve({ valid: false, reason: 'no_license' });
          return;
        }
        resolve(response || { valid: false, reason: 'no_license' });
      });
      
      // Timeout fallback
      setTimeout(() => {
        if (!resolved) {
          resolved = true;
          resolve({ valid: false, reason: 'no_license' });
        }
      }, 2000);
    });
    
    console.log('License status:', status);
  
  if (status && status.valid) {
    if (status.trial) {
      // Trial mode
      licenseStatus.className = 'status-card trial';
      statusIcon.textContent = '🎁';
      statusText.textContent = `Dùng thử: ${status.daysLeft} phút`;
      statusBadge.textContent = 'Trial';
      statusBadge.className = 'status-badge trial';
      ytStatus.textContent = 'Hoạt động';
      ytStatus.classList.remove('off');
      licenseInputSection.classList.add('show');
      devicesSection.style.display = 'none';
      infoText.innerHTML = `⏰ Còn ${status.daysLeft} phút dùng thử<br>💡 Nhập License Key để sử dụng trọn đời`;
    } else {
      // Full license
      licenseStatus.className = 'status-card active';
      statusIcon.textContent = '✅';
      statusText.textContent = 'Đã kích hoạt';
      statusBadge.textContent = 'Pro';
      statusBadge.className = 'status-badge pro';
      ytStatus.textContent = 'Hoạt động';
      ytStatus.classList.remove('off');
      ytStatus.textContent = 'Hoạt động';
      ytStatus.classList.remove('off');
      licenseInputSection.classList.remove('show');
      devicesSection.style.display = 'block';
      infoText.innerHTML = `✨ Chặn quảng cáo đang hoạt động`;
      
      // Load devices list
      const licenseData = await chrome.storage.local.get([STORAGE_KEY]);
      if (licenseData[STORAGE_KEY]?.key) {
        // Decrypt the key before using it
        const decryptedKey = decryptKey(licenseData[STORAGE_KEY].key);
        loadDevices(decryptedKey);
      }
    }
  } else {
    // Not activated
    licenseStatus.className = 'status-card inactive';
    statusIcon.textContent = '🔒';
    statusText.textContent = 'Chưa kích hoạt';
    statusBadge.textContent = 'Free';
    statusBadge.className = 'status-badge';
    ytStatus.textContent = 'Tắt';
    ytStatus.classList.add('off');
    licenseInputSection.classList.add('show');
    devicesSection.style.display = 'none';
    infoText.innerHTML = `🔓 Nhập License Key để chặn quảng cáo`;
  }
  } catch (error) {
    console.error('UpdateUI error:', error);
    // Fallback to inactive state
    licenseStatus.className = 'status-card inactive';
    statusIcon.textContent = '🔒';
    statusText.textContent = 'Chưa kích hoạt';
    statusBadge.textContent = 'Free';
    statusBadge.className = 'status-badge';
  }
}

function reloadPage() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.reload(tabs[0].id);
      setTimeout(() => window.close(), 100);
    }
  });
}

// Load devices list
async function loadDevices(licenseKey) {
  try {
    const response = await fetch(ACTIVATIONS_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licenseKey })
    });

    const data = await response.json();
    
    console.log('Activations response:', { status: response.status, data });

    if (!response.ok) {
      console.error('API error response:', data);
      devicesList.innerHTML = `<div class="no-devices">❌ Lỗi tải danh sách (${response.status})</div>`;
      return;
    }

    if (!data.success) {
      console.error('API returned success: false', data);
      const errorMsg = data.message || data.error || 'Lỗi không xác định';
      devicesList.innerHTML = `<div class="no-devices">❌ Lỗi tải danh sách: ${errorMsg}</div>`;
      return;
    }

    // Update device count
    deviceCountText.textContent = `Đã kích hoạt: ${data.activeDevices}/${data.maxDevices}`;

    // Display devices
    if (data.activations.length === 0) {
      devicesList.innerHTML = `<div class="no-devices">Chưa có thiết bị nào</div>`;
      return;
    }

    const isLastDevice = (data.activations.length === 1);

    devicesList.innerHTML = data.activations.map(device => `
      <div class="device-item">
        <div class="device-info">
          <div class="device-name">${device.deviceName}</div>
          <div class="device-date">Kích hoạt: ${new Date(device.activatedAt).toLocaleDateString('vi-VN')}</div>
        </div>
        ${isLastDevice ? '' : `<button class="device-remove" data-activation-id="${device.id}">🗑️ Xóa</button>`}
      </div>
    `).join('');

    // Add event listeners to all remove buttons
    document.querySelectorAll('.device-remove').forEach(btn => {
      btn.addEventListener('click', () => removeDevice(btn.dataset.activationId, licenseKey));
    });
    
  } catch (error) {
    console.error('Load devices error:', error);
    devicesList.innerHTML = `<div class="no-devices">❌ Lỗi kết nối server: ${error.message}</div>`;
  }
}

// Remove device
async function removeDevice(activationId, licenseKey) {
  console.log('Removing device:', { activationId, licenseKey });
  
  if (!confirm('Bạn chắc chắn muốn xóa thiết bị này?')) return;

  try {
    // Get current device activation before removing
    const currentLicense = await chrome.storage.local.get([STORAGE_KEY]);
    const currentActivationId = currentLicense[STORAGE_KEY]?.activationId;
    const isRemovingCurrentDevice = (activationId === currentActivationId);
    
    // Get device list to check if this is the last device
    const listResponse = await fetch(ACTIVATIONS_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licenseKey })
    });
    const listData = await listResponse.json();
    const totalDevices = listData.activations?.length || 0;
    const isLastDevice = (totalDevices === 1);
    
    const response = await fetch(DEACTIVATE_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licenseKey, activationId })
    });

    console.log('Response status:', response.status);
    const data = await response.json();
    console.log('Response data:', data);

    if (data.success) {
      alert('✅ Xóa thiết bị thành công!');
      
      // If we removed the current device
      if (isRemovingCurrentDevice) {
        if (isLastDevice) {
          // This was the last device - re-activate immediately
          console.log('Last device removed, re-activating...');
          
          const reactivateResponse = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ licenseKey })
          });
          
          const reactivateData = await reactivateResponse.json();
          
          if (reactivateData.valid) {
            await chrome.storage.local.set({
              [STORAGE_KEY]: {
                key: licenseKey,
                valid: true,
                activatedAt: new Date().toISOString(),
                plan: reactivateData.plan,
                expiresAt: reactivateData.expiry || null,
                activationId: reactivateData.activationId
              }
            });
            console.log('Re-activation successful');
          }
        } else {
          // Not the last device - deactivate this extension
          console.log('Current device removed (other devices remain), deactivating...');
          await chrome.storage.local.remove(STORAGE_KEY);
          alert('⚠️ Thiết bị này đã bị xóa. Extension đã được vô hiệu hóa.\n💡 Nhập lại License Key nếu muốn sử dụng tiếp.');
        }
      }
      
      // Reload devices list and UI
      await loadDevices(licenseKey);
      await updateUI();
      
    } else {
      alert(`❌ ${data.message || data.error || 'Lỗi xóa thiết bị'}`);
    }
  } catch (error) {
    console.error('Remove device error:', error);
    alert('❌ Lỗi kết nối server');
  }
}

// Encryption helper (matches background.js)
function encryptKey(key) {
  return btoa(key); // Base64 encode
}

function decryptKey(encryptedKey) {
  try {
    return atob(encryptedKey); // Base64 decode
  } catch (e) {
    console.error('Decrypt error:', e);
    return encryptedKey; // Fallback to original if decode fails
  }
}

// Activation moved to popup input section - no separate activation page needed

// Handle license input submission
async function handleLicenseSubmit() {
  const licenseKey = licenseKeyInput.value.trim();
  
  if (!licenseKey) {
    showLicenseMessage('❌ Vui lòng nhập License Key', 'error');
    return;
  }
  
  // Disable button during submission
  submitLicenseBtn.disabled = true;
  submitLicenseBtn.textContent = '⏳ Đang kiểm tra...';
  
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ licenseKey })
    });
    
    const data = await response.json();
    
    if (response.ok && data.valid) {
      // Save to storage with encrypted key
      chrome.storage.local.set({
        [STORAGE_KEY]: {
          key: encryptKey(licenseKey), // Encrypt before saving
          valid: true,
          activatedAt: new Date().toISOString(),
          plan: data.plan,
          expiresAt: data.expiry || null,
          activationId: data.activationId
        }
      }, () => {
        showLicenseMessage('✅ Kích hoạt thành công!', 'success');
        licenseKeyInput.value = '';
        
        // Update UI after short delay
        setTimeout(() => {
          updateUI();
          // Reload YouTube tab to apply license
          reloadPage();
        }, 500);
      });
    } else {
      showLicenseMessage(data.message || '❌ License key không hợp lệ', 'error');
    }
  } catch (error) {
    console.error('License validation error:', error);
    showLicenseMessage('❌ Lỗi kết nối server', 'error');
  } finally {
    submitLicenseBtn.disabled = false;
    submitLicenseBtn.textContent = 'Kích hoạt';
  }
}

// Show message for license input
function showLicenseMessage(text, type) {
  licenseMessage.textContent = text;
  licenseMessage.className = `license-message ${type}`;
  
  if (type === 'success') {
    setTimeout(() => {
      licenseMessage.className = 'license-message';
    }, 3000);
  }
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('submitLicenseBtn').addEventListener('click', handleLicenseSubmit);
  document.getElementById('licenseKeyInput').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      handleLicenseSubmit();
    }
  });
  
  // Buy License button
  document.getElementById('buyLicenseBtn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'http://localhost:3000/buy' });
  });
});

// Initialize
console.log('Initializing popup...');
updateUI().catch(err => {
  console.error('Update UI error:', err);
  // Fallback UI
  licenseStatus.className = 'license-status inactive';
  licenseStatus.innerHTML = `
    <span class="license-text">🔒 Chưa kích hoạt</span>
    <span class="license-badge badge-inactive">Free</span>
  `;
  activateBtn.style.display = 'inline-block';
});

console.log('AdBlock Pro popup loaded');
