// Background Service Worker - License Management

const STORAGE_KEY = 'adblock_license';
const API_URL = 'http://localhost:3000/api/validate-license';
const CREATE_TRIAL_API = 'http://localhost:3000/api/create-trial';

// Simple encryption/decryption (Base64 encoding for basic obfuscation)
// Not cryptographically secure but prevents casual reading
function encryptKey(key) {
  return btoa(key); // Base64 encode
}

function decryptKey(encrypted) {
  try {
    return atob(encrypted); // Base64 decode
  } catch {
    return null;
  }
}

// Generate device fingerprint
function generateDeviceFingerprint() {
  return new Promise((resolve) => {
    const userAgent = navigator.userAgent;
    const language = navigator.language;
    
    // Simple hash of user-agent + language
    const combined = `${userAgent}|${language}`;
    let hash = 0;
    for (let i = 0; i < combined.length; i++) {
      const char = combined.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    resolve(Math.abs(hash).toString(16));
  });
}

// Installation listener - no longer opens activation on install
// Users can activate directly from popup

// Check license status
async function checkLicenseStatus() {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get([STORAGE_KEY], async (result) => {
        if (chrome.runtime.lastError) {
          console.error('Storage error:', chrome.runtime.lastError);
          resolve({ valid: false, reason: 'storage_error' });
          return;
        }
        
        const license = result[STORAGE_KEY];
        
        if (!license) {
          // Call API to create trial or check if device already used trial
          try {
            const userAgent = navigator.userAgent;
            const language = navigator.language;
            
            const response = await fetch(CREATE_TRIAL_API, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ userAgent, language })
            });

            const data = await response.json();

            if (!data.success) {
              // Device already used trial
              resolve({ valid: false, reason: 'trial_already_used' });
              return;
            }

            // Store trial locally
            const trialData = {
              skipped: true,
              skippedAt: new Date().toISOString()
            };
            chrome.storage.local.set({ [STORAGE_KEY]: trialData });

            resolve({ valid: true, trial: true, daysLeft: 1 });
          } catch (error) {
            console.error('Create trial error:', error);
            // Fallback: allow local trial (5 minutes for testing)
            const trialData = {
              skipped: true,
              skippedAt: new Date().toISOString()
            };
            chrome.storage.local.set({ [STORAGE_KEY]: trialData });
            resolve({ valid: true, trial: true, daysLeft: 5 });
          }
          return;
        }
      
      if (license.valid && license.key) {
        // Check if expired
        if (license.expiresAt) {
          const expiresDate = new Date(license.expiresAt);
          if (expiresDate < new Date()) {
            resolve({ valid: false, reason: 'expired' });
            return;
          }
        }
        resolve({ valid: true, license });
      } else if (license.skipped) {
        // Allow trial mode for 30 minutes (testing)
        const skippedDate = new Date(license.skippedAt);
        const minutesSinceSkip = (new Date() - skippedDate) / (1000 * 60);
        
        if (minutesSinceSkip > 30) {
          resolve({ valid: false, reason: 'trial_expired' });
        } else {
          const minutesLeft = Math.ceil(30 - minutesSinceSkip);
          resolve({ valid: true, trial: true, daysLeft: minutesLeft > 0 ? minutesLeft : 0 });
        }
      } else if (license.key) {
        // Validate license key with server every time
        // This prevents using old/cracked keys
        try {
          const decrypted = decryptKey(license.key);
          if (!decrypted) {
            resolve({ valid: false, reason: 'invalid_key_format' });
            return;
          }
          
          // Server-side validation
          const validateResponse = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ licenseKey: decrypted })
          });
          
          const validationResult = await validateResponse.json();
          
          if (validationResult.valid) {
            resolve({ valid: true, license, trial: false });
          } else {
            // Key is invalid or expired
            resolve({ valid: false, reason: 'license_invalid', message: validationResult.message });
          }
        } catch (error) {
          console.error('License validation error:', error);
          // If validation fails, still allow if stored license exists (offline mode)
          resolve({ valid: true, license, offline: true });
        }
      } else {
        resolve({ valid: false, reason: 'invalid_license' });
      }
    });
    } catch (error) {
      console.error('Check license error:', error);
      resolve({ valid: false, reason: 'error' });
    }
  });
}

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'checkLicense') {
    checkLicenseStatus()
      .then(status => {
        sendResponse(status);
      })
      .catch(err => {
        console.error('Check license error:', err);
        sendResponse({ valid: false, reason: 'error' });
      });
    return true; // Keep channel open for async response
  }
  
  if (request.action === 'openActivation') {
    chrome.tabs.create({
      url: chrome.runtime.getURL('activation.html')
    });
    sendResponse({ success: true });
    return false;
  }
  
  return false;
});

// Periodic license validation (every 24 hours)
chrome.alarms.create('validateLicense', { periodInMinutes: 1440 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'validateLicense') {
    const status = await checkLicenseStatus();
    
    if (status.valid && status.license && !status.trial) {
      // Re-validate with server
      try {
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ licenseKey: status.license.key })
        });
        
        const data = await response.json();
        
        if (!data.valid) {
          // Invalidate local license
          chrome.storage.local.set({
            [STORAGE_KEY]: { valid: false, reason: 'server_invalid' }
          });
        }
      } catch (error) {
        console.error('License validation error:', error);
      }
    }
  }
});

console.log('AdBlock Pro service worker active with license management');
