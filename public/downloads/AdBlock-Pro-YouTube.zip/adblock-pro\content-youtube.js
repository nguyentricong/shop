// YouTube Super AdBlock 2025 - Stealth MAX Edition with License Check
(function() {
  'use strict';

  let isLicenseValid = false;
  let isTrial = false;

  // Check license status
  async function checkLicense() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: 'checkLicense' }, (response) => {
        if (response) {
          isLicenseValid = response.valid;
          isTrial = response.trial || false;
          resolve(response);
        } else {
          resolve({ valid: false });
        }
      });
    });
  }

  console.log('%c[YT AdBlocker] Stealth Engine Loaded', 'color:#4CAF50;font-weight:bold');

  // ============================================================
  // 1. SAFE-CLEAN PLAYER RESPONSE (UNDETECTABLE)
  // ============================================================

  function cleanPlayerResponse(obj) {
    // Only clean ads if license is valid or in trial
    if (!isLicenseValid && !isTrial) {
      return obj;
    }
    
    if (!obj || typeof obj !== "object") return obj;

    const adKeys = [
      "adPlacements",
      "playerAds",
      "adBreaks",
      "adSlots",
      "adAnnotations",
      "trackingParams",
      "adSafetyReasons"
    ];

    adKeys.forEach(key => {
      if (key in obj) {
        Object.defineProperty(obj, key, {
          value: undefined,
          writable: false,
          enumerable: false,
          configurable: false
        });
      }
    });

    // Clean adaptive formats
    if (obj.streamingData?.adaptiveFormats) {
      obj.streamingData.adaptiveFormats = obj.streamingData.adaptiveFormats.filter(
        f => !f.url?.includes("ctier=") && !f.url?.includes("ad")
      );
    }

    return obj;
  }

  // Patch ytInitialPlayerResponse (stealth safe)
  let realValue;
  Object.defineProperty(window, "ytInitialPlayerResponse", {
    configurable: true,
    get() { return realValue; },
    set(val) {
      realValue = cleanPlayerResponse(val);
      return true;
    }
  });

  // ============================================================
  // 2. JSON.parse PATCH – STEALTH MODE (HARD TO DETECT)
  // ============================================================

  const _json = JSON.parse;
  JSON.parse = function(str, reviver) {
    const out = _json(str, reviver);
    if (out && typeof out === "object") {
      if (out.adPlacements || out.playerAds || out.adBreaks) {
        return cleanPlayerResponse(out);
      }
    }
    return out;
  };

  // ============================================================
  // 3. SAFE AD SKIPPER (NO ERROR – NO DETECT)
  // ============================================================

  function safeSkipAds() {
    // Only skip ads if license is valid or in trial
    if (!isLicenseValid && !isTrial) {
      return;
    }
    
    const video = document.querySelector('video');
    const player = document.querySelector('#movie_player');

    if (!video || !player) return;

    // Only skip if YT flags "ad-showing"
    if (!player.classList.contains("ad-showing")) return;

    const duration = video.duration;

    // Duration not ready → do nothing
    if (!duration || !isFinite(duration) || duration === Infinity) return;

    // Skip like human behavior
    video.currentTime = duration - 0.1;
    video.muted = true;
  }

  // Don't start intervals here - wait for license check

  // ============================================================
  // 4. STEALTH AD UI HIDING (NOT REMOVING DOM)
  // ============================================================

  const HIDE_SELECTORS = [
    '.ytp-ad-player-overlay',
    '.ytp-ad-image-overlay',
    '.ytp-ad-text-overlay',
    '.ytp-ad-preview-container',
    '.ytp-ad-message-container',
    'ytd-ad-slot-renderer',
    'ytd-in-feed-ad-layout-renderer',
    'ytd-promoted-sparkles-web-renderer',
    '.video-ads'
  ];

  function stealthHideAds() {
    // Only hide ads if license is valid or in trial
    if (!isLicenseValid && !isTrial) {
      return;
    }
    
    HIDE_SELECTORS.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        el.style.opacity = "0";
        el.style.pointerEvents = "none";
        el.style.visibility = "hidden";
        el.style.display = "none";
      });
    });
  }

  // Don't start intervals here - wait for license check

  // ============================================================
  // 5. BYPASS ANTI-ADBLOCK — STEALTH (FAKE CONSENT & REMOVE POPUP)
  // ============================================================

  function removeAntiAdblock() {
    // Only remove anti-adblock if license is valid or in trial
    if (!isLicenseValid && !isTrial) {
      return;
    }
    
    const list = [
      'ytd-enforcement-message-view-model',
      'yt-upsell-dialog-renderer',
      'tp-yt-paper-dialog',
      '#dialog',
      '#consent-bump',
      'ytd-ad-feedback-dialog-renderer'
    ];

    list.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        el.style.display = "none";
        el.remove?.();
      });
    });
  }

  // Don't start intervals here - wait for license check

  // Fake consent cookies to stop YT from re-checking
  document.cookie = "CONSENT=YES+cb; path=/; domain=.youtube.com";

  // ============================================================
  // 6. CLOAKING — HIDE OUR PATCHES FROM YOUTUBE
  // ============================================================

  // Hide modified functions (undetectable)
  function cloak(fn) {
    Object.defineProperty(fn, "toString", {
      value: () => "function () { [native code] }",
      writable: false
    });
  }

  cloak(JSON.parse);
  cloak(cleanPlayerResponse);
  cloak(safeSkipAds);

  // ============================================================
  // 7. LICENSE CHECK & INITIALIZATION
  // ============================================================

  async function initializeAdBlocker() {
    const status = await checkLicense();
    
    if (!status.valid) {
      // Don't show banner, don't run ad blocker
      console.log('%c[YT AdBlocker] License required - ads will show', 'color:#ff9800;font-weight:bold');
      return;
    }
    
    console.log('%c[YT AdBlocker] License valid - Running...', 'color:#4CAF50;font-weight:bold');
    
    // Start ad blocking intervals only if licensed/trial
    setInterval(safeSkipAds, 300);
    setInterval(stealthHideAds, 300);
    setInterval(removeAntiAdblock, 300);
  }

  // Run license check on load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeAdBlocker);
  } else {
    initializeAdBlocker();
  }

})();
